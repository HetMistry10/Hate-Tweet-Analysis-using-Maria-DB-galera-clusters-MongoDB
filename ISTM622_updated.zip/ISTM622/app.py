import pymongo
from flask import Flask, render_template, jsonify, request
from bson.json_util import dumps

app = Flask(__name__)

#Connecting to MongoDB instance on local server
client = pymongo.MongoClient("mongodb://localhost:27017/")
db = client['temp2']
collection = db['twitter']


@app.route('/')
def home():
    return render_template('HateTweet.html')


# Top negative tweets promoting terrorism targeting at specific countries
@app.route('/Terrorism/countries')
def terrorism_countries():
    pipeline = [ {u"$match":    {'terrorism_empath':      {u"$gte": 20, } } },  {u"$group":   {u"_id":u"$countries_mentioned", u"count":{u"$sum":1}}}, {u"$sort":{u"count":-1}}]
    docs=[]
    cursor = collection.aggregate(pipeline, allowDiskUse=False)
    try:
        for doc in cursor:
            docs.append(doc)
        return jsonify(docs)
    finally:
        client.close()

# Display users of which states have highest terror empathy influence on he basis of hatred comments mentioned by politicians about muslim countries and hastags realted to those countries
@app.route('/Terrorism/hatred')
def terrorism_hatred():
    pipeline = [ {u"$match":{'countries_mentioned':    { u"$in": ["Iraq","Iran"] } } },{u"$group":{u"_id":{'user_state':u"$user_state"},'Number_of_People':{u"$sum":1}}}, {u"$sort":{"Number_of_People":1}}]
    docs = []
    cursor = collection.aggregate(pipeline, allowDiskUse=False)
    try:
        for doc in cursor:
            docs.append(doc)
        return jsonify(docs)
    finally:
        client.close()

# Display the state and the terror influence of tweets made by users belonging to that particular state including the total number of such statuses categorized by state having highest reach among public
@app.route('/Terrorism/states')
def terrorism_states():
    pipeline = [{u"$match":{'terrorism_empath':{u"$gte": 20} } }, {u"$group":  {u"_id":{'state':u"$user_state"},'followers_count':{u"$sum":1}}}, {u"$sort":{'followers_count':-1}}]
    docs = []
    cursor = collection.aggregate(pipeline, allowDiskUse=False)
    try:
        for doc in cursor:
            docs.append(doc)
        return jsonify(docs)
    finally:
        client.close()

# Top Negative/ sarcastic Tweets targetting potential PM candidates for US 2020 elections with their influence
@app.route('/Politics/pmcandidates')
def politics_pmcandidates():
    pipeline = [{u"$match":	{'politics_empath':  	{ u"$gte": 20,} } },  {"$group":   {u"_id": {'PMcandidate':u"$politician_mentioned"}, u"count":{u"$sum":1}}}, {u"$sort":{u"count":-1}}]
    docs = []
    cursor = collection.aggregate(pipeline, allowDiskUse=False)
    try:
        for doc in cursor:
            docs.append(doc)
        return jsonify(docs)
    finally:
        client.close()


# The number of people and their Social Networking Potential (Influence) on others by doing political campaigning in twitter by using hate tweets
@app.route('/Politics/campaign')
def politics_campaign():
    pipeline = [{u"$match":{u"$and": [{'politics_empath':{ u"$gte": 12,} }, {'mentions':{u"$gte":350}}, {u"$or":[{'hashtags':{u"$regex":'MAGA'}},{'hashtags':{u"$regex":'makeamericagreatagain'}},{'hashtags':{u"$regex":'buildthewall'}}]} ] } }, {u"$group":  {u"_id":{'State':u"$user_state"}, 'Number_of_People':{u"$sum":1}}}, {u"$sort":{'Number_of_People':-1}}]
    docs = []
    cursor = collection.aggregate(pipeline, allowDiskUse=False)
    try:
        for doc in cursor:
            docs.append(doc)
        return jsonify(docs)
    finally:
        client.close()

# The politicians mentioned by users who have more political and criminal influence based on the tweets
@app.route('/Politics/crime')
def politics_crime():
    pipeline = [{u"$match":{u"$and":[{'politics_empath':{u"$gte": 12,}},{'mentions':{u"$gte":350}},{'crime_empath':{u"$gte":6}}]}}, {u"$group":{u"_id":{"Politician":u"$politician_mentioned","State":u"$user_state"}}}]
    docs = []
    cursor = collection.aggregate(pipeline, allowDiskUse=False)
    try:
        for doc in cursor:
            docs.append(doc)
        return jsonify(docs)
    finally:
        client.close()

# The number of people and their tweet influence on others about Donald Trump in twitter
@app.route('/Politics/trump')
def politics_trump():
    pipeline = [{u"$match":{u"$and": [{'politician_mentioned':'Donald Trump'},{'politics_empath':{ u"$gte": 12,}},{'mentions':{u"$gte":50}},{u"$or":[{'hashtags': {u"$regex":'MAGA'}},{'hashtags':{u"$regex":'makeamericagreatagain'}},{'hashtags':{u"$regex":'buildthewall'}}]} ] } },{u"$group":  {u"_id":{'Politician':u"$politician_mentioned"}, 'Total_Users':{u"$sum":1}}}]
    docs = []
    cursor = collection.aggregate(pipeline, allowDiskUse=False)
    try:
        for doc in cursor:
            docs.append(doc)
        return jsonify(docs)
    finally:
        client.close()

# Top Negative tweets regarding jobs and employment of different states and their influence
@app.route('/Economy/jobs')
def economy_jobs():
    pipeline = [{u"$match":{ u"$and": [{'occupation_empath':{ u"$gte":2,}}, {u"$or":[{'hashtags': {u"$regex":'Employment'}},{'hashtags': {u"$regex":'Career'}},{'hashtags': {u"$regex":'Hiring'}},{'hashtags': {u"$regex":'Recession'}},{'hashtags': {u"$regex":'Resume'}},{'hashtags': {u"$regex":'Unemployement'}}]} ] } }, {u"$group":  {u"_id":{'State':u"$user_state"}, 'Total_Users':{u"$sum":1}}}]
    docs = []
    cursor = collection.aggregate(pipeline, allowDiskUse=False)
    try:
        for doc in cursor:
            docs.append(doc)
        return jsonify(docs)
    finally:
        client.close()

# Top Negative tweets regarding international work authorization and visa and their influence
@app.route('/Economy/visa')
def economy_visa():
    pipeline = [{u"$match":{ u"$and": [{'occupation_empath':{ u"$gte":2,}}, {u"$or":[{'hashtags': {u"$regex":'H1'}},{'hashtags': {u"$regex":'Visa'}},{'hashtags': {u"$regex":'CPT'}},{'hashtags': {u"$regex":'OPT'}},{'hashtags': {u"$regex":'H1-B'}},{'hashtags': {u"$regex":'Employement'}}]} ] } }, {u"$group":  {u"_id":{'State':u"$user_state"}, 'Total_Users':{u"$sum":1}}}]
    docs = []
    cursor = collection.aggregate(pipeline, allowDiskUse=False)
    try:
        for doc in cursor:
            docs.append(doc)
        return jsonify(docs)
    finally:
        client.close()

# States where the impact/influence of the tweets related to crime is maximum
@app.route('/Crime/states')
def crime_states():
    pipeline = [{u"$match":{'crime_empath': {u"$gte": 12, } } }, {u"$group":   {u"_id":u"$user_state", u"count":{u"$sum":1}}}, {u"$sort":{u"count":-1}}]
    docs = []
    cursor = collection.aggregate(pipeline, allowDiskUse=False)
    try:
        for doc in cursor:
            docs.append(doc)
        return jsonify(docs)
    finally:
        client.close()

# Apprehend the trend of death related tweets in states of the USA
@app.route('/Crime/death')
def crime_death():
    pipeline = [{u"$match":{'death_empath': {u"$gte": 12, } } }, {u"$group":   {u"_id":u"$user_state", u"count":{u"$sum":1}}}, {u"$sort":{u"count":-1}}]
    docs = []
    cursor = collection.aggregate(pipeline, allowDiskUse=False)
    try:
        for doc in cursor:
            docs.append(doc)
        return jsonify(docs)
    finally:
        client.close()


if __name__ == "__main__":
    app.debug = True;
    app.run()